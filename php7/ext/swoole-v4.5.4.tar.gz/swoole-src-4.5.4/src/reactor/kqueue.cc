/*
 +----------------------------------------------------------------------+
 | Swoole                                                               |
 +----------------------------------------------------------------------+
 | This source file is subject to version 2.0 of the Apache license,    |
 | that is bundled with this package in the file LICENSE, and is        |
 | available through the world-wide-web at the following url:           |
 | http://www.apache.org/licenses/LICENSE-2.0.html                      |
 | If you did not receive a copy of the Apache2.0 license and are unable|
 | to obtain it through the world-wide-web, please send a note to       |
 | license@swoole.com so we can mail you a copy immediately.            |
 +----------------------------------------------------------------------+
 | Author: Tianfeng Han  <mikan.tenny@gmail.com>                        |
 +----------------------------------------------------------------------+
 */

#include "swoole.h"
#include "swoole_socket.h"
#include "swoole_reactor.h"
#include "swoole_signal.h"
#include "swoole_log.h"

using swoole::Reactor;
using swoole::ReactorHandler;
using swoole::network::Socket;

#ifdef IDE_HELPER
#ifdef HAVE_KQUEUE
#include <sys/event.h>
#else
#define USE_KQUEUE_IDE_HELPER
#include "helper/kqueue.h"
#define HAVE_KQUEUE
#endif
#else
#ifdef HAVE_KQUEUE
#include <sys/event.h>
#endif
#endif

#ifdef HAVE_KQUEUE

struct swReactorKqueue {
    int epfd;
    int event_max;
    struct kevent *events;
};

static int swReactorKqueue_add(Reactor *reactor, Socket *socket, int events);
static int swReactorKqueue_set(Reactor *reactor, Socket *socket, int events);
static int swReactorKqueue_del(Reactor *reactor, Socket *socket);
static int swReactorKqueue_wait(Reactor *reactor, struct timeval *timeo);
static void swReactorKqueue_free(Reactor *reactor);

static sw_inline bool swReactorKqueue_fetch_event(Reactor *reactor, swEvent *event, void *udata) {
    event->socket = (Socket *) udata;
    event->fd = event->socket->fd;
    event->type = event->socket->fdtype;
    event->reactor_id = reactor->id;

    if (event->socket->removed) {
        return false;
    }
    return true;
}

static sw_inline void swReactorKqueue_del_once_socket(Reactor *reactor, Socket *socket) {
    if ((socket->events & SW_EVENT_ONCE) && !socket->removed) {
        swReactorKqueue_del(reactor, socket);
    }
}

int swReactorKqueue_create(Reactor *reactor, int max_event_num) {
    int epfd = kqueue();
    if (epfd < 0) {
        swWarn("[swReactorKqueueCreate] kqueue_create[0] fail");
        return SW_ERR;
    }

    reactor->add = swReactorKqueue_add;
    reactor->set = swReactorKqueue_set;
    reactor->del = swReactorKqueue_del;
    reactor->wait = swReactorKqueue_wait;
    reactor->free = swReactorKqueue_free;

    swReactorKqueue *object = new swReactorKqueue();
    reactor->max_event_num = max_event_num;
    object->event_max = max_event_num;
    object->events = new struct kevent[max_event_num];
    object->epfd = epfd;
    reactor->object = object;

    return SW_OK;
}

static void swReactorKqueue_free(Reactor *reactor) {
    swReactorKqueue *object = (swReactorKqueue *) reactor->object;
    close(object->epfd);
    delete[] object->events;
    delete object;
}

static int swReactorKqueue_add(Reactor *reactor, Socket *socket, int events) {
    swReactorKqueue *object = (swReactorKqueue *) reactor->object;
    struct kevent e;
    int ret;

    int fd = socket->fd;
    int fflags = 0;

    if (swReactor_event_read(events)) {
#ifdef NOTE_EOF
        fflags = NOTE_EOF;
#endif
        EV_SET(&e, fd, EVFILT_READ, EV_ADD, fflags, 0, socket);
        ret = kevent(object->epfd, &e, 1, nullptr, 0, nullptr);
        if (ret < 0) {
            swSysWarn("add events[fd=%d#%d, type=%d, events=read] failed", fd, reactor->id, socket->fdtype);
            return SW_ERR;
        }
    }

    if (swReactor_event_write(events)) {
        EV_SET(&e, fd, EVFILT_WRITE, EV_ADD, 0, 0, socket);
        ret = kevent(object->epfd, &e, 1, nullptr, 0, nullptr);
        if (ret < 0) {
            swSysWarn("add events[fd=%d#%d, type=%d, events=write] failed", fd, reactor->id, socket->fdtype);
            return SW_ERR;
        }
    }

    reactor->_add(socket, events);
    swTraceLog(SW_TRACE_EVENT, "[THREAD #%d]EP=%d|FD=%d, events=%d", SwooleTG.id, object->epfd, fd, socket->events);

    return SW_OK;
}

static int swReactorKqueue_set(Reactor *reactor, Socket *socket, int events) {
    swReactorKqueue *object = (swReactorKqueue *) reactor->object;
    struct kevent e;
    int ret;

    int fd = socket->fd;
    int fflags = 0;

    if (swReactor_event_read(events)) {
#ifdef NOTE_EOF
        fflags = NOTE_EOF;
#endif
        EV_SET(&e, fd, EVFILT_READ, EV_ADD, fflags, 0, socket);
        ret = kevent(object->epfd, &e, 1, nullptr, 0, nullptr);
        if (ret < 0) {
            swSysWarn("kqueue->set(%d, SW_EVENT_READ) failed", fd);
            return SW_ERR;
        }
    } else {
        EV_SET(&e, fd, EVFILT_READ, EV_DELETE, 0, 0, socket);
        ret = kevent(object->epfd, &e, 1, nullptr, 0, nullptr);
        if (ret < 0) {
            swSysWarn("kqueue->del(%d, SW_EVENT_READ) failed", fd);
            return SW_ERR;
        }
    }

    if (swReactor_event_write(events)) {
        EV_SET(&e, fd, EVFILT_WRITE, EV_ADD, 0, 0, socket);
        ret = kevent(object->epfd, &e, 1, nullptr, 0, nullptr);
        if (ret < 0) {
            swSysWarn("kqueue->set(%d, SW_EVENT_WRITE) failed", fd);
            return SW_ERR;
        }
    } else {
        EV_SET(&e, fd, EVFILT_WRITE, EV_DELETE, 0, 0, socket);
        ret = kevent(object->epfd, &e, 1, nullptr, 0, nullptr);
        if (ret < 0) {
            swSysWarn("kqueue->del(%d, SW_EVENT_WRITE) failed", fd);
            return SW_ERR;
        }
    }

    reactor->_set(socket, events);
    swTraceLog(SW_TRACE_EVENT, "[THREAD #%d]EP=%d|FD=%d, events=%d", SwooleTG.id, object->epfd, fd, socket->events);

    return SW_OK;
}

static int swReactorKqueue_del(Reactor *reactor, Socket *socket) {
    swReactorKqueue *object = (swReactorKqueue *) reactor->object;
    struct kevent e;
    int ret;
    int fd = socket->fd;

    if (socket->removed) {
        swoole_error_log(
            SW_LOG_WARNING, SW_ERROR_EVENT_SOCKET_REMOVED, "failed to delete event[%d], has been removed", socket->fd);
        return SW_ERR;
    }

    if (socket->events & SW_EVENT_READ) {
        EV_SET(&e, fd, EVFILT_READ, EV_DELETE, 0, 0, socket);
        ret = kevent(object->epfd, &e, 1, nullptr, 0, nullptr);
        if (ret < 0) {
            swSysWarn("kqueue->del(%d, SW_EVENT_READ) failed", fd);
            if (errno != EBADF && errno != ENOENT) {
                return SW_ERR;
            }
        }
    }

    if (socket->events & SW_EVENT_WRITE) {
        EV_SET(&e, fd, EVFILT_WRITE, EV_DELETE, 0, 0, socket);
        ret = kevent(object->epfd, &e, 1, nullptr, 0, nullptr);
        if (ret < 0) {
            swSysWarn("kqueue->del(%d, SW_EVENT_WRITE) failed", fd);
            if (errno != EBADF && errno != ENOENT) {
                return SW_ERR;
            }
        }
    }

    reactor->_del(socket);
    swTraceLog(SW_TRACE_EVENT, "[THREAD #%d]EP=%d|FD=%d", SwooleTG.id, object->epfd, fd);

    return SW_OK;
}

static int swReactorKqueue_wait(Reactor *reactor, struct timeval *timeo) {
    swEvent event;
    swReactorKqueue *object = (swReactorKqueue *) reactor->object;
    ReactorHandler handler;

    int i, n;
    struct timespec t = {};
    struct timespec *t_ptr;

    if (reactor->timeout_msec == 0) {
        if (timeo == nullptr) {
            reactor->timeout_msec = -1;
        } else {
            reactor->timeout_msec = timeo->tv_sec * 1000 + timeo->tv_usec / 1000;
        }
    }

    reactor->before_wait();

    while (reactor->running) {
        if (reactor->onBegin != nullptr) {
            reactor->onBegin(reactor);
        }
        if (reactor->timeout_msec > 0) {
            t.tv_sec = reactor->timeout_msec / 1000;
            t.tv_nsec = (reactor->timeout_msec - t.tv_sec * 1000) * 1000 * 1000;
            t_ptr = &t;
        } else if (reactor->defer_tasks) {
            t.tv_sec = 0;
            t.tv_nsec = 0;
            t_ptr = &t;
        } else {
            t_ptr = nullptr;
        }

        n = kevent(object->epfd, nullptr, 0, object->events, object->event_max, t_ptr);
        if (n < 0) {
            if (swReactor_error(reactor) < 0) {
                swWarn("kqueue[#%d], epfd=%d", reactor->id, object->epfd);
                return SW_ERR;
            } else {
                goto _continue;
            }
        } else if (n == 0) {
            reactor->execute_end_callbacks(true);
            SW_REACTOR_CONTINUE;
        }

        swTraceLog(SW_TRACE_EVENT, "n %d events", n);

        for (i = 0; i < n; i++) {
            struct kevent *kevent = &object->events[i];
            void *udata = (void *) kevent->udata;
            if (!udata) {
                continue;
            }
            switch (kevent->filter) {
            case EVFILT_READ:
            case EVFILT_WRITE: {
                if (swReactorKqueue_fetch_event(reactor, &event, udata)) {
                    handler = reactor->get_handler(kevent->filter == EVFILT_READ ? SW_EVENT_READ : SW_EVENT_WRITE,
                                                   event.type);
                    if (sw_unlikely(handler(reactor, &event) < 0)) {
                        swSysWarn("kqueue event %s socket#%d handler failed",
                                  kevent->filter == EVFILT_READ ? "read" : "write",
                                  event.fd);
                    }
                    swReactorKqueue_del_once_socket(reactor, event.socket);
                }
                break;
            }
            case EVFILT_SIGNAL: {
                struct sw_signal {
                    swSignalHandler handler;
                    uint16_t signo;
                    uint16_t active;
                };
                struct sw_signal *sw_signal = (struct sw_signal *) udata;

                if (sw_signal->active) {
                    if (sw_signal->handler) {
                        sw_signal->handler(sw_signal->signo);
                    } else {
                        swoole_error_log(SW_LOG_WARNING,
                                         SW_ERROR_UNREGISTERED_SIGNAL,
                                         SW_UNREGISTERED_SIGNAL_FMT,
                                         swSignal_str(sw_signal->signo));
                    }
                }
                break;
            }
            default:
                swWarn("unknown event filter[%d]", kevent->filter);
                break;
            }
        }

    _continue:
        reactor->execute_end_callbacks(false);
        SW_REACTOR_CONTINUE;
    }
    return 0;
}
#endif
